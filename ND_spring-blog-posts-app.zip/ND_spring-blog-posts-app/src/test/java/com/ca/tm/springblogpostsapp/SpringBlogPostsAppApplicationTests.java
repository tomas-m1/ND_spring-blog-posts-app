package com.ca.tm.springblogpostsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBlogPostsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
