package com.ca.tm.springblogpostsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBlogPostsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBlogPostsAppApplication.class, args);
	}

}
