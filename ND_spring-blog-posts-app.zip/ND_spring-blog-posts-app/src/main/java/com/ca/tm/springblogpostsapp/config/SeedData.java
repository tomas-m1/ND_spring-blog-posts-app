package com.ca.tm.springblogpostsapp.config;

import com.ca.tm.springblogpostsapp.models.Account;
import com.ca.tm.springblogpostsapp.models.Authority;
import com.ca.tm.springblogpostsapp.models.Post;
import com.ca.tm.springblogpostsapp.repositories.AuthorityRepository;
import com.ca.tm.springblogpostsapp.services.AccountService;
import com.ca.tm.springblogpostsapp.services.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class SeedData implements CommandLineRunner  {

    @Autowired
    private PostService postService;

    @Autowired
    private AccountService accountService;

    @Autowired
    private AuthorityRepository authorityRepository;

    @Override
    public void run(String... args) throws Exception {
        List<Post> posts = postService.getAll();

        if (posts.size() == 0) {

            Account account1 = new Account();
            Account account2 = new Account();

            account1.setFirstname("user");
            account1.setLastname("user");
            account1.setEmail("user.user@domain.com");
            account1.setPassword("password");
            Set<Authority> authorities1 = new HashSet<>();
            authorityRepository.findById("ROLE_USER").ifPresent(authorities1::add);
            account1.setAuthorities(authorities1);

            account2.setFirstname("admin");
            account2.setLastname("admin");
            account2.setEmail("admin.admin@domain.com");
            account2.setPassword("password");
            Set<Authority> authorities2 = new HashSet<>();
            authorityRepository.findById("ROLE_USER").ifPresent(authorities2::add);
            authorityRepository.findById("ROLE_ADMIN").ifPresent(authorities2::add);
            account2.setAuthorities(authorities2);

            accountService.save(account1);
            accountService.save(account2);


            Post post1 = new Post();
            post1.setTitle("title of post1");
            post1.setBody("body of the post1");
            post1.setAccount(account1);

            Post post2 = new Post();
            post2.setTitle("title of post2");
            post2.setBody("body of thee post2");
            post2.setAccount(account2);

            postService.save(post1);
            postService.save(post2);
        }
    }
}
